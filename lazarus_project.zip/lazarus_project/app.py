import pandas as pd
import streamlit as st
import pyttsx3

# -------------------------------
# 🔊 Voice Alert Function
# -------------------------------
def speak(text):
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except:
        st.warning("Voice alert not supported on your system")

# -------------------------------
# 💊 Decode Medicine Function
# -------------------------------
def decode_medicine(med):
    if pd.isna(med):
        return ""
    med = str(med)
    return ''.join(chr(ord(c)-1) if c.isalpha() else c for c in med)

# -------------------------------
# ⚠️ Risk Detection (Basic AI logic)
# -------------------------------
def detect_risk(text):
    text = str(text).lower()
    risky_words = ["error", "wrong", "overdose", "duplicate"]
    for word in risky_words:
        if word in text:
            return "⚠️ Risk Detected"
    return "✅ Safe"

# -------------------------------
# 🎯 Streamlit UI
# -------------------------------
st.set_page_config(page_title="Project Lazarus", layout="wide")

st.title("💊 Project Lazarus - AI Prescription Analyzer")
st.write("Upload and analyze prescriptions with decoding + risk detection + voice alert 🔥")

# -------------------------------
# 📂 File Upload
# -------------------------------
uploaded_file = st.file_uploader("Upload Prescription CSV", type=["csv"])

if uploaded_file is not None:
    prescriptions = pd.read_csv(uploaded_file)

    st.subheader("📊 Dataset Preview")
    st.write(prescriptions.head())

    # -------------------------------
    # 🔍 Auto-detect medicine column
    # -------------------------------
    medicine_col = None
    for col in prescriptions.columns:
        if "med" in col.lower():
            medicine_col = col
            break

    if medicine_col is None:
        st.error("❌ No medicine column found!")
        st.stop()
    else:
        st.success(f"✅ Using column: {medicine_col}")

    # -------------------------------
    # 🧠 Process Data
    # -------------------------------
    prescriptions['decoded'] = prescriptions[medicine_col].apply(decode_medicine)
    prescriptions['risk'] = prescriptions['decoded'].apply(detect_risk)

    # -------------------------------
    # 📊 Show Results
    # -------------------------------
    st.subheader("📊 Processed Data")
    st.dataframe(prescriptions)

    # -------------------------------
    # 🔊 Voice Alert Button
    # -------------------------------
    if st.button("🔊 Alert for Risks"):
        risky = prescriptions[prescriptions['risk'] == "⚠️ Risk Detected"]

        if len(risky) > 0:
            msg = f"Warning! {len(risky)} risky prescriptions detected"
            speak(msg)
            st.error(msg)
        else:
            msg = "All prescriptions are safe"
            speak(msg)
            st.success(msg)

    # -------------------------------
    # 📈 Simple Stats
    # -------------------------------
    st.subheader("📈 Summary")
    st.write(prescriptions['risk'].value_counts())

else:
    st.info("📂 Please upload a CSV file to begin.")